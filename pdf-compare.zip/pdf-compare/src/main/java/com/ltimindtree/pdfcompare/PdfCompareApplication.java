package com.ltimindtree.pdfcompare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfCompareApplication {

    public static void main(String[] args) {
        SpringApplication.run(PdfCompareApplication.class, args);
    }

}
