package com.ltimindtree.pdfcompare.web.controller;

import com.ltimindtree.pdfcompare.service.FileService;
import com.ltimindtree.pdfcompare.service.PdfUtilityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/files")
public class FileController {

    private final PdfUtilityService pdfUtilityService;
    private final FileService fileService;

    public FileController(PdfUtilityService pdfUtilityService, FileService fileService) {
        this.pdfUtilityService = pdfUtilityService;
        this.fileService = fileService;
    }

    @RequestMapping(value = "/compare", method = RequestMethod.POST, consumes = "multipart/form-data")
    public ResponseEntity<byte[]> comparePDFs(
            @RequestParam("original") MultipartFile original,
            @RequestParam("modified") MultipartFile modified
    ) {
        try {
            String originalFilePath = fileService.uploadFile(original, "original");
            String modifiedFilePath = fileService.uploadFile(modified, "modified");

            // Convert PDF files to images
            Map<Integer, BufferedImage> originalBufferedImagesMap = pdfUtilityService.convertPDFToImage(new File(originalFilePath));
            Map<Integer, BufferedImage> modifiedBufferedImagesMap = pdfUtilityService.convertPDFToImage(new File(modifiedFilePath));

            Map<Integer, List<BufferedImage>> diffImagesMap = pdfUtilityService.comparePDFs(
                    originalBufferedImagesMap,
                    modifiedBufferedImagesMap
            );

            if (diffImagesMap.isEmpty()) {
                return ResponseEntity.ok(null);
            } else {
                String diffPdfPath = pdfUtilityService.createDiffPdf(originalBufferedImagesMap, diffImagesMap);

                // Prepare file response
                File file = new File(diffPdfPath);
                byte[] fileContent = Files.readAllBytes(file.toPath());

                // Set headers for the file response
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
                headers.setContentDispositionFormData("diffFile", diffPdfPath);

                // file response
                return ResponseEntity.ok()
                        .headers(headers)
                        .body(fileContent);
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
