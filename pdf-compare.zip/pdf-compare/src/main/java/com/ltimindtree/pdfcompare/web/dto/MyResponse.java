package com.ltimindtree.pdfcompare.web.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MyResponse {
    private String json;
    private byte[] file;
}