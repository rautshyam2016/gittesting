package com.ltimindtree.pdfcompare.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.web.multipart.MultipartFile;

public interface FileService {

    String uploadFile(MultipartFile file, String tag) throws Exception;

    String saveFile(PDDocument document, String diff) throws Exception;
}
